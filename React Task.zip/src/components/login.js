import React, { Component } from 'react'
import { connect } from 'react-redux'

class Login extends Component {

    componentDidMount(){
        let authorisedUser = this.props.authorisedUser;
        this.setState({
            ...this.state,
            authorisedUser
        })
    }

    handleInputChange = (e) => {
        this.setState({
            [e.target.name] : e.target.value
        })
    }

    handleSubmit = () => {
        let {username,password,authorisedUser} = this.state;
        if(username === authorisedUser.username && password === authorisedUser.password){
            this.setState({
                errorMsg : null
            })
            window.location.href='/dashboard'
        }else{
            this.setState({
                errorMsg : 'Username or Password is incorrect !!'
            })
        }
    }
    
    render() {
        return (
            <div style={{marginTop:'10%',}} className="App" >
                <input type='text' name="username" placeholder='Username' onChange={this.handleInputChange} />&nbsp;
                <input type='text' name="password" placeholder='password' onChange={this.handleInputChange} />&nbsp;&nbsp;
                <button onClick={this.handleSubmit}>Login</button>
                {
                this.state?.errorMsg 
                    ? <p style={{color:'red',fontSize:'px',fontFamily:'helvetica',fontStyle:'italic'}} >{this.state?.errorMsg}</p> 
                    : null
                }
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        authorisedUser : state.authorisedUser
    }
}

export default connect(mapStateToProps)(Login);