import React from 'react'
import { Route, BrowserRouter as Router, Switch } from 'react-router-dom'
import Dashboard from './dashboard'
import Login from './login'

function Routing() {
    return (
        <Router>
            <Switch>
                <Route exact path='/' component={Login}></Route>
                <Route exact path='/login' component={Login}></Route>
                <Route exact path='/dashboard' component={Dashboard} ></Route>
            </Switch>
        </Router>
    )
}

export default Routing
