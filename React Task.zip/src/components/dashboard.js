import React, { useState } from 'react'
import { useSelector } from 'react-redux';

function Dashboard() {

    let listOfusers = useSelector(state => state.user);
    const [searchingFor, setSearchingFor] = useState(null);

    let handleFilter = e => {
        if(searchingFor && searchingFor !== null){
            let newData = listOfusers?.filter(item => item.name.toLowerCase().includes(searchingFor.toLowerCase()));
            return newData;
        }else{
            return listOfusers
        }
    }

    return (
        <div style={{width:'35%',margin:'20px'}}>
            <div >
                <input type="text" placeholder='Search for user !!' onChange={(e) => setSearchingFor(e.target.value)} style={{width:'100%'}}/>
            </div><br/>
            <table cellspacing='12' cellPadding='5' style={{border:'1px solid black'}} >
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Mobile</th>
                {handleFilter()?.map(user => {
                    return(
                        <tr>
                            <td>{user.name}</td>
                            <td>{user.age}</td>
                            <td>{user.gender}</td>
                            <td>{user.email}</td>
                            <td>{user.phoneNo}</td>
                        </tr>
                    )
                })}
            </table><br/>
            <button onClick={() => window.location.href = '/login'}>Back to login</button>
        </div>
    )
}

export default Dashboard