import { Provider } from 'react-redux';
import './App.css';
import Routing from './components/Routing';
import store from './redux/store';

function App() {
  return (
    <Provider store={store} >
      <div >
        <Routing/>
      </div>
    </Provider>
  );
}

export default App;
